const _="domain-analyzer-popup",A="SUBSCRIBE_TAB",E="TAB_DOMAINS_UPDATE";export{_ as P,A as S,E as T};
